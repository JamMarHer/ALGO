This class aims to illustrate the differences in a stack based
and recursive based implementation of the Ackermann function.

To run:

1. Compile with -javac Ackermann.java

2. Run the program with -java Ackermann m n
	where m and n are the desired m and n values of the function.